# Sloth Token Game Bot
A simple Telegram bot game for Sloth Token.